const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

let numberFamilies, numberMember, bus = 0, busPassenger = 0

rl.question('input the number of families : ', (numberFamilies) => {
    rl.question('input the number of members in the family : ', (numberMember) => {
        let arr = numberMember.split(" ").sort();
        if (arr.length != numberFamilies) {
            console.log("input must be equal with count of family");
            rl.close();
            return;
        }
        arr.forEach((item) => {
            busPassenger += item
            if (busPassenger >= 4) {
                busPassenger = 0
                bus++
            }
        })
        console.log(`Minimum bus required is : ${bus}`)
        rl.close();
    });
});