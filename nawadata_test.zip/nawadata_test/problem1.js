const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const problem1 = () => {
    const vowels = ["a", "i", "u", "e", "o"];
    const vowelResult = [];
    const ConsonantsResult = [];
    rl.question('Input 1 line of words : ', (words) => {
        for (let i of words) {
            if (vowels.includes(i)) {
                vowelResult.push(i);
            }
            if (!vowels.includes(i)) {
                ConsonantsResult.push(i);
            }
        }
        let resultVowel = vowelResult.sort().join('').toLowerCase();
        let resultConsonants = ConsonantsResult.sort().join("").toLowerCase().trim();
        console.log(`Vowel Characters : ${resultVowel}`);
        console.log(`Consonant Characters : ${resultConsonants}`);
        rl.close();
    });
}

problem1();
